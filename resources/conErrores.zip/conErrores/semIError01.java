///[Error:A|7]
// 
class A{

}

class A{

}

class Init{
    static void main()
    { }
}
