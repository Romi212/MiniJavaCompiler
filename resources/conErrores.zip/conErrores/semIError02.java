///[Error:C|7]

class A{

}

class B extends C{

}


class Init{
    static void main()
    { }
}
