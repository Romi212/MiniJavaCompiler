///[Error:m1|19]

class A {
    void m1()
    {}
    
    static void m2()
    {}
    
    void m3(int p1, String p2)
    {}
    
    void m4(int p3, boolean p4)
    {}
    
}

class B extends A{
    int m1()
    {}
}



class Init{
    static void main()
    { }
}


