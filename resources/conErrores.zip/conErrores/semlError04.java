///[Error:a|6]
//
class A{

    private int a;
    private char a;
}

class A{

}

class Init{
    static void main()
    { }
}
