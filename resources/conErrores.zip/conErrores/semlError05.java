///[Error:void|6]
//
class A{

    private int b;
    private void a;
}

class A{

}

class Init{
    static void main()
    { }
}
