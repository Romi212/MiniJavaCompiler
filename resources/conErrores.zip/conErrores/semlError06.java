///[Error:met1|6]
//
class A{

    private int met1(int a);
    private char met1(int a);
}

class A{

}

class Init{
    static void main()
    { }
}
