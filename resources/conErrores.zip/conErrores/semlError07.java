///[Error:A|9]
//
class A{

    private int met1(int a);
    A(int v){
        a = v;
    }
    A(char f){}
}

class A{

}

class Init{
    static void main()
    { }
}
