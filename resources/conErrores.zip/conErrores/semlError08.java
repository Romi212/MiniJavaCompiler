///[Error:B|6]
//
class A{

    private int met1(int a);
    B(int v){
        a = v;
    }

}

class A{

}

class Init{
    static void main()
    { }
}
