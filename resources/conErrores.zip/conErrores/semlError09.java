///[Error:att|5]
//
class A{

    private int met1(int att, char att);
    private char met2(int a);
}

class A{

}

class Init{
    static void main()
    { }
}
