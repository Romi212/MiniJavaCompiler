///[Error:A|3]
//
class A extends B{

    private int met1(int att, char at1);
    private char met2(int a);

}

class B extends A{

}

class C extends A{

}

class Init{
    static void main()
    { }
}
