///[Error:B|3]
//
class A extends B{

    private int met1(int att, char a2);
    private char met2(int a);

}

class C extends A{

}

class Init{
    static void main()
    { }
}
